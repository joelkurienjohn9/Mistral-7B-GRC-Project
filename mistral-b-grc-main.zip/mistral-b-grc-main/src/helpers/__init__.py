"""
Helper utilities for the Mistral-B-GRC project.

Available utilities:
- fix_adapter_root: Fix adapter directories by copying files from latest checkpoint
"""

__version__ = "1.0.0"
